<div id="loader"> <i class="fa fa-cog fa-4x fa-spin"></i> </div>

<!-- ============ PAGE LOADER END ============ --> 

<!-- ============ NAVBAR START ============ -->
<link rel="shortcut icon" href="images/favicon.png">

    <!-- Main Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

<div class="fm-container"> 
  <!-- Menu -->
  <div class="menu">
    <div class="button-close text-right"> <a class="fm-button"><i class="fa fa-close fa-2x"></i></a> </div>
    <ul class="nav">
      <li class="active"><a href="index.php">Home</a></li>
      <!-- <li><a href="jobs2.php">Jobs</a></li> -->
      <!-- <li><a href="candidates.php">Candidates</a></li> -->
      <!-- <li><a href="post-a-job.php">Post a job</a></li> -->
      <li><a href="about.php">About Us</a></li>
      <li><a href="company.php">Our Process</a></li>
      <!-- <li><a href="post-a-resume.html">Post a Resume</a></li> -->
    

      <?php 
        

      if(isset($_SESSION['user_id'])){ 
        
         $result=mysql_query("SELECT count(*) as total from TBL_EMPLOYEE_DEL where user_id='".$_SESSION['user_id']."'");
          $sql=mysql_fetch_assoc($result);

            if ($sql['total'] > 0) {
             
              echo "<li><a href='view_profile.php'>View My Profile</a></li>";
            }else{
              echo "<li><a href='emp_type.php'>Upload Your Profile</a></li>";
            }
         echo "<li><a href='logout.php'>Logout</a></li>";
      }else{
        echo "<li><a href='signup.php'>Sign Up</a></li>";
        echo "<li><a href='signin.php'>Sign In</a></li>";
      } ?>
      </li>
    </ul>
  </div>
  <!-- end Menu --> 
</div>





<!-- ============ NAVBAR END ============ --> 

<!-- ============ HEADER START ============ -->


<header>
  <div class="navbar navbar-default" style="margin-top:-10px; height: 90px;">
  <div class="navbar-header">
    <!-- <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div> -->
      <div class="navbar-brand">
          <div id="logo"><a href="index.html"><img src="images/logo_new.png" alt="ITS Recruitment" /></a></div>
        </div>
  </div>      
    <ul class="nav navbar-nav pull-right" style="margin-right:80px;">
    
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="company.php">Our Process</a></li>
       <?php 
        

      if(isset($_SESSION['user_id'])){ 

        echo "<li class='dropdown'><a class='dropdown-toggle' data-toggle='dropdown' style='text-transform:capitalize;'>".$_SESSION['name']." &nbsp; <span class='caret'></span></a>";
        echo "<ul role='menu' class='dropdown-menu'>";

         $result=mysql_query("SELECT count(*) as total from TBL_EMPLOYEE_DEL where user_id='".$_SESSION['user_id']."'");
          $sql=mysql_fetch_assoc($result);

            if ($sql['total'] > 0) {
             
              echo "<li><a href='view_profile.php'>View/Edit My Profile</a></li>";
            }else{
              echo "<li><a href='emp_type.php'>Upload Your Profile</a></li>";
            }
            echo "<li><a href='logout.php'>Logout</a></li>";
           ?>
          </ul></li>
        <?php
        

      }else{
        echo "<li><a href='signup.php'>Sign Up</a></li>";
        echo "<li><a href='signin.php'>Sign In</a></li>";
      } ?>

    </ul>
  
</div>
      
    </header>

<!-- <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 1-1</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li> 
        </ul>
      </li> -->