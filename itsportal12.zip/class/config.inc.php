<?php
session_start();
error_reporting("Error");

	//**************** include classes *************************
	require_once("global.config.php");
	require_once("database.inc.php");
	require_once("class.Authentication.php");
	require_once("class.FormValidation.php");
	require_once("ClsJSFormValidation.cls.php");
	
	define("Siteurl","http://www.itstraining.in/shakedup/",true);
//	
    define("DATABASE_HOST","localhost",true);
    define("DATABASE_PORT","3306",true);
    define("DATABASE_USER","learnsof_shakedu",true);
    define("DATABASE_PASSWORD",")T1s*w#6T+C5",true);
    define("DATABASE_NAME","learnsof_shackedup",true);
//	
//	define("DATABASE_HOST","localhost",true);
////	define("DATABASE_PORT","3306",true);
//	define("DATABASE_USER","amitpal_user34",true);
//	define("DATABASE_PASSWORD","mkx@z]M&g7?_",true);
//	define("DATABASE_NAME","amitpal_shaked",true);
//	
	//*************** Set Time Zone ***************************//
	
	date_default_timezone_set("Asia/Calcutta");                     
	
?>