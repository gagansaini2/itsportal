<?php
/*********Admin Module***************/

// master management tables

define("TBL_USER",'tbl_user',true);
define("TBL_EMPLOYEE_DEL",'tbl_employee_del',true);
define("TBL_EMPLOYEE_EXP",'tbl_employee_exp',true);
define("TBL_EMPLOYEE_EDD",'tbl_employee_edd',true);
define("TBL_COMPANY",'tbl_company',true);
define("TBL_OTHERS",'tbl_others',true);
define("TBL_EMPLOYEE_CERTIFICATION",'tbl_employee_certification',true);
define("TBL_EMPLOYEE_WORKEX",'tbl_employee_workex',true);
define("TBL_EMPLOYEE_KEYSKILS",'tbl_employee_keyskils',true);
define("TBL_JOBS",'tbl_jobs',true);
define("TBL_SKILLS",'tbl_skills',true);
define("TBL_IMAGE",'tbl_image',true);



?>