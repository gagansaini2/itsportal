<?php
/*********Admin Module***************/

// master management tables

define("TBL_USER",'tbl_user',true);
define("TBL_EMPLOYEE_DEL",'tbl_employee_del',true);
define("TBL_EMPLOYEE_EXP",'tbl_employee_exp',true);
define("TBL_EMPLOYEE_EDD",'tbl_employee_edd',true);
define("TBL_COMPANY",'tbl_company',true);
define("TBL_OTHERS",'tbl_others',true);
define("TBL_EMPLOYEE_CERTIFICATION",'tbl_employee_certification',true);
define("TBL_EMPLOYEE_WORKEX",'tbl_employee_workex',true);
define("TBL_EMPLOYEE_KEYSKILS",'tbl_employee_keyskils',true);
define("TBL_JOBS",'tbl_jobs',true);
define("TBL_SKILLS",'tbl_skills',true);
define("TBL_IMAGE",'tbl_image',true);
define("TBL_STATELIST",'tbl_statelist',true);
define("TBL_LANGUAGES",'tbl_languages',true);
define("TBL_EMPINFO",'tbl_empinfo',true);
define("TBL_COUNTRYCODE",'tbl_countrycode',true);
define("TBL_RESUME",'tbl_resume',true);
define("TBL_LOGO",'tbl_logo',true);
define("TBL_COURSETYPE",'tbl_coursetype',true);
define("TBL_SPECIFICATION",'tbl_specification',true);
define("TBL_JOBSKILLS",'tbl_jobskills',true);
define("TBL_COUNTRIES",'tbl_countries',true);
define("TBL_EMP_RESPONDED",'tbl_emp_responded',true);

?>