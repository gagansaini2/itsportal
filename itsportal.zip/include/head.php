



<ul class="nav nav-pills" style="margin-bottom:3em;">
  <li id="li1"><a style="cursor: default;">Personal</a></li>
  <li id="li2"><a style="cursor: default;">Academics</a></li>
  <li id="li3"><a style="cursor: default;">Experience</a></li>
  <li id="li4"><a style="cursor: default;">Other Details</a></li>
  
</ul>

