<?php require_once("class/config.inc.php");

?>