<?php 
require_once("class/config.inc.php");
require_once("class/global.config.php");
require_once("class/database.inc.php");
require_once("class/class.Authentication.php");
require_once("class/class.auth.php");


?>