
  'use strict';




 
app.controller('login', ["$scope", "$http", "$user_service", "$timeout", function($scope, $http, $user_service, $timeout) {


$scope.forget_pass=function(){

$("#forgot").modal('show');

}

$scope.login={};

$scope.forget=function(){

    // if (isValid) {
    	
  // console.log($scope.login);

  $user_service.forgot($scope.login.email).then(function(){
    $("#recovrmsg").show();

    $timeout(function(){
      
      $("#forgot").modal('hide');
      $scope.login="";
      $("#recovrmsg").hide();
    
    },4000)
   
    
  },function(){

  })

  // };

}


$scope.panelforgot=function(){

$("#loginModal").modal('hide');
$("#forgot").modal('show'); 


}







$scope.loginpan={};

$scope.signin=function(){
  // console.log("yo");

      $.ajax({
              
          method: "POST",
          url: "api.php?work=panel_login",

          data: $scope.loginpan,
         
         
                      
         success:function(data){

          var callback = JSON.parse(data);
          console.log(callback.status);
          
          if (callback.status == true) {
            
                $("#loginerr").hide();
              location.reload();
          }

          if (callback.status == false){
              $("#loginerr").show();
                

          }

         
         }


      })


}




}])


